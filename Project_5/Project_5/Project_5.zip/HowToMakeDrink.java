package Project_5;

public interface HowToMakeDrink {
    public void prepare();
}
